/******************************************************/
// С��Ƕ��ʽ������    www.xcembed.com
// ���ߣ� ��㳬@����   xcembed.blog.chinaunix.net
//
//  USB Camera���ղ��Գ���
//  �÷���cam2img /dev/video0 640x480 picname.jpg
/******************************************************/

#include <stdio.h>   
#include <stdlib.h>   
#include <string.h>   
#include <assert.h>    
#include <getopt.h>     /* getopt_long() */    
#include <fcntl.h>      /* low-level i/o */   
#include <unistd.h>   
#include <errno.h>  
#include <sys/stat.h>   
#include <sys/types.h>   
#include <sys/time.h>   
#include <sys/mman.h>   
#include <sys/ioctl.h>  
#include <asm/types.h>      /* for videodev2.h */     
#include <linux/videodev2.h>
#include <jpeglib.h>
#include "utils.h"

#define V4L2_CID_SHARPNESS			(V4L2_CID_BASE+27) 
  
#define CLEAR(x) memset (&(x), 0, sizeof (x))  

#define ARRAY_SIZE(a)		(sizeof(a) / sizeof((a)[0]))
#define FOURCC_FORMAT		"%c%c%c%c"
#define FOURCC_ARGS(c)		(c) & 0xFF, ((c) >> 8) & 0xFF, ((c) >> 16) & 0xFF, ((c) >> 24) & 0xFF  //add by xgc 
int enum_frame_intervals(int dev, __u32 pixfmt, __u32 width, __u32 height);
int enum_frame_sizes(int dev, __u32 pixfmt);
int enum_frame_formats(int dev, unsigned int *supported_formats, unsigned int max_formats);
  
struct buffer  
{  
	unsigned char *start;  
	size_t length;  
};  
  
static char *dev_name = NULL;  
static char *filename = NULL;
static char *resolution = NULL; 

static int pixel_format = V4L2_PIX_FMT_MJPEG;  
static int fd = -1;  
struct buffer *buffers = NULL;  
static unsigned int n_buffers = 0;  
static unsigned int width = 640;  
static unsigned int height = 480;  
static unsigned int count = 16;
static unsigned int pic_num = 0;

//add by xgc
int enum_frame_sizes(int dev, __u32 pixfmt)
{
	int ret;
	struct v4l2_frmsizeenum fsize;

	memset(&fsize, 0, sizeof(fsize));
	fsize.index = 0;
	fsize.pixel_format = pixfmt;
	while ((ret = ioctl(dev, VIDIOC_ENUM_FRAMESIZES, &fsize)) == 0) {
		if (fsize.type == V4L2_FRMSIZE_TYPE_DISCRETE) {
			printf("{ discrete: width = %u, height = %u }\n",
					fsize.discrete.width, fsize.discrete.height);
			ret = enum_frame_intervals(dev, pixfmt,
					fsize.discrete.width, fsize.discrete.height);
			if (ret != 0)
				printf("  Unable to enumerate frame sizes.\n");
		} else if (fsize.type == V4L2_FRMSIZE_TYPE_CONTINUOUS) {
			printf("{ continuous: min { width = %u, height = %u } .. "
					"max { width = %u, height = %u } }\n",
					fsize.stepwise.min_width, fsize.stepwise.min_height,
					fsize.stepwise.max_width, fsize.stepwise.max_height);
			printf("  Refusing to enumerate frame intervals.\n");
			break;
		} else if (fsize.type == V4L2_FRMSIZE_TYPE_STEPWISE) {
			printf("{ stepwise: min { width = %u, height = %u } .. "
					"max { width = %u, height = %u } / "
					"stepsize { width = %u, height = %u } }\n",
					fsize.stepwise.min_width, fsize.stepwise.min_height,
					fsize.stepwise.max_width, fsize.stepwise.max_height,
					fsize.stepwise.step_width, fsize.stepwise.step_height);
			printf("  Refusing to enumerate frame intervals.\n");
			break;
		}
		fsize.index++;
	}
	if (ret != 0 && errno != EINVAL) {
		perror("ERROR enumerating frame sizes");
		return errno;
	}

	return 0;
}

int enum_frame_formats(int dev, unsigned int *supported_formats, unsigned int max_formats)
{
	int ret;
	struct v4l2_fmtdesc fmt;

	memset(&fmt, 0, sizeof(fmt));
	fmt.index = 0;
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	while ((ret = ioctl(dev, VIDIOC_ENUM_FMT, &fmt)) == 0) {
		if(supported_formats == NULL) {
			printf("{ pixelformat = '%c%c%c%c', description = '%s' }\n",
					fmt.pixelformat & 0xFF, (fmt.pixelformat >> 8) & 0xFF,
					(fmt.pixelformat >> 16) & 0xFF, (fmt.pixelformat >> 24) & 0xFF,
					fmt.description);
			ret = enum_frame_sizes(dev, fmt.pixelformat);
			if(ret != 0)
				printf("  Unable to enumerate frame sizes.\n");
		}
		else if(fmt.index < max_formats) {
			supported_formats[fmt.index] = fmt.pixelformat;
		}

		fmt.index++;
	}
	if (errno != EINVAL) {
		perror("ERROR enumerating frame formats");
		return errno;
	}

	return 0;
}

int enum_frame_intervals(int dev, __u32 pixfmt, __u32 width, __u32 height)
{
	int ret;
	struct v4l2_frmivalenum fival;

	memset(&fival, 0, sizeof(fival));
	fival.index = 0;
	fival.pixel_format = pixfmt;
	fival.width = width;
	fival.height = height;
	printf("\tTime interval between frame: ");
	while ((ret = ioctl(dev, VIDIOC_ENUM_FRAMEINTERVALS, &fival)) == 0) {
		if (fival.type == V4L2_FRMIVAL_TYPE_DISCRETE) {
				printf("%u/%u, ",
						fival.discrete.numerator, fival.discrete.denominator);
		} else if (fival.type == V4L2_FRMIVAL_TYPE_CONTINUOUS) {
				printf("{min { %u/%u } .. max { %u/%u } }, ",
						fival.stepwise.min.numerator, fival.stepwise.min.numerator,
						fival.stepwise.max.denominator, fival.stepwise.max.denominator);
				break;
		} else if (fival.type == V4L2_FRMIVAL_TYPE_STEPWISE) {
				printf("{min { %u/%u } .. max { %u/%u } / "
						"stepsize { %u/%u } }, ",
						fival.stepwise.min.numerator, fival.stepwise.min.denominator,
						fival.stepwise.max.numerator, fival.stepwise.max.denominator,
						fival.stepwise.step.numerator, fival.stepwise.step.denominator);
				break;
		}
		fival.index++;
	}
	printf("\n");
	if (ret != 0 && errno != EINVAL) {
		perror("ERROR enumerating frame intervals");
		return errno;
	}

	return 0;
}
//add by xgc 
  
static void errno_exit(const char *s)  
{  
	fprintf(stderr, "%s error %d, %s\n", s, errno, strerror(errno));  
	exit(EXIT_FAILURE);  
}  
  
static int xioctl(int fd, int request, void *arg)  
{  
	int r;  
	  
	do  
		r = ioctl(fd, request, arg);  
	while (-1 == r && EINTR == errno);  
	  
	return r;  
}  
  
static void uninit_device(void)  
{  
	unsigned int i;  
 
	for (i = 0; i < n_buffers; ++i)  
		if (-1 == munmap(buffers[i].start, buffers[i].length))  
			errno_exit("munmap");  
  
	free(buffers);  
}  

static void start_capture(void)
{  
	struct v4l2_requestbuffers req;  
	
	struct v4l2_buffer buf;  
	CLEAR(buf);  
  
	CLEAR(req);  
  
	req.count = 4;  
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  
	req.memory = V4L2_MEMORY_MMAP;  
  
	if (-1 == xioctl(fd, VIDIOC_REQBUFS, &req))  
	{  
		if (EINVAL == errno)  
		{  
			fprintf(stderr, "%s does not support "  
			"memory mapping\n", dev_name);  
			exit(EXIT_FAILURE);  
		}  
		else  
		{  
			errno_exit("VIDIOC_REQBUFS");  
		}  
	}  
  
	if (req.count < 2)  
	{  
		fprintf(stderr, "Insufficient buffer memory on %s\n", dev_name);  
		exit(EXIT_FAILURE);  
	}  
  
	buffers = calloc(req.count, sizeof(*buffers));  
  
	if (!buffers)  
	{  
		fprintf(stderr, "Out of memory\n");  
		exit(EXIT_FAILURE);  
	}  
  
	for (n_buffers = 0; n_buffers < req.count; ++n_buffers)  
	{  

  
		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  
		buf.memory = V4L2_MEMORY_MMAP;  
		buf.index = n_buffers;  
  
		if (-1 == xioctl(fd, VIDIOC_QUERYBUF, &buf))  
			errno_exit("VIDIOC_QUERYBUF");  
  
		buffers[n_buffers].length = buf.length;  
		buffers[n_buffers].start = mmap(NULL /* start anywhere */ ,  
                      buf.length,  
                      PROT_READ | PROT_WRITE /* required */ ,  
                      MAP_SHARED /* recommended */ ,  
                      fd, buf.m.offset);  
  
		if (MAP_FAILED == buffers[n_buffers].start)  
		errno_exit("mmap");

		if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))  
			errno_exit("VIDIOC_QBUF");  

		//printf("Frame buffer %d: address=0x%x, length=%d\n", n_buffers, (unsigned int)buffers[n_buffers].start, buffers[n_buffers].length);			
	}  
	
	enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  //add 0606
	if (-1 == xioctl(fd, VIDIOC_STREAMON, &type))  
		errno_exit("VIDIOC_STREAMON"); 

	while(count != 0)
	{		
		fd_set fds;  
		struct timeval tv;  
		int r;  

		FD_ZERO(&fds);  
		FD_SET(fd, &fds);  

		/* Timeout. */  
		tv.tv_sec = 2;  
		tv.tv_usec = 0;  

		r = select(fd + 1, &fds, NULL, NULL, &tv);  

		if (-1 == r)  
		{  
			errno_exit("select");  
		}  

		if (0 == r)  
		{  
			fprintf(stderr, "select timeout\n");  
			exit(EXIT_FAILURE);  
		}  

		if (-1 == xioctl(fd, VIDIOC_DQBUF, &buf))  
		{  
			printf("VIDIOC_DQBUF exit?\n");
			switch (errno)  
			{  
				case EAGAIN:  
					return 0;  

				default:  
				errno_exit("VIDIOC_DQBUF");  
			}  
		} 

		//assert(buf.index < n_buffers); 		

		if(count == 1)
			get_picture(buffers[buf.index].start, buf.bytesused, filename);

		count--;


		if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))  
			errno_exit("VIDIOC_QBUF");  
	}
}
  
static int init_device(void)  
{  
	struct v4l2_capability cap;  
	struct v4l2_cropcap cropcap;  
	struct v4l2_crop crop;  
	struct v4l2_format fmt;
	struct v4l2_control   control_s;
	unsigned int min;  
  
	if (-1 == xioctl(fd, VIDIOC_QUERYCAP, &cap))  
	{  
		if (EINVAL == errno)  
		{  
			fprintf(stderr, "%s is no V4L2 device\n", dev_name);  
			exit(EXIT_FAILURE);  
		}  
		else  
		{  
			errno_exit("VIDIOC_QUERYCAP");  
		}  
	}  

	if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE))  
	{  
		fprintf(stderr, "%s is no video capture device\n", dev_name);  
		exit(EXIT_FAILURE);  
	}  
    
	/* Select video input, video standard and tune here. */   
	cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  
  
	if (-1 == xioctl(fd, VIDIOC_CROPCAP, &cropcap))  
  
	crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  
	crop.c = cropcap.defrect; /* reset to default */  
  
	if (-1 == xioctl(fd, VIDIOC_S_CROP, &crop))  
	{  
		switch (errno)  
		{  
			case EINVAL:  
				break;  
			default:  
				break;  
		}  
	} 
	 
	CLEAR(fmt);  
  
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;  
	fmt.fmt.pix.width = width;  
	fmt.fmt.pix.height = height;  
	fmt.fmt.pix.pixelformat = pixel_format;  
	fmt.fmt.pix.field = V4L2_FIELD_ANY;  
  
	if (-1 == xioctl(fd, VIDIOC_S_FMT, &fmt))  
		errno_exit("VIDIOC_S_FMT");  
	
	width = fmt.fmt.pix.width;
	height = fmt.fmt.pix.height;

	control_s.id = V4L2_CID_SHARPNESS;
        control_s.value = 11;
	if (-1 == xioctl(fd, VIDIOC_S_CTRL, &control_s))  
		errno_exit("VIDIOC_S_CTRL"); 
	//fprintf(stderr, "set sharpness value:%d\n", control_s.value); 
}  
  
static void close_device(void)  
{  
	if (-1 == close(fd))  
		errno_exit("close");  
  
	fd = -1;  
}  
  
static void open_device(void)  
{  
	struct stat st;  
  
	if (-1 == stat(dev_name, &st))  
	{  
		fprintf(stderr, "Cannot identify '%s': %d, %s\n",  
			dev_name, errno, strerror(errno));  
		exit(EXIT_FAILURE);  
	}  
  
	if (!S_ISCHR(st.st_mode))  
	{  
		fprintf(stderr, "%s is no device\n", dev_name);  
		exit(EXIT_FAILURE);  
	}  
  
	fd = open(dev_name, O_RDWR /* required */  | O_NONBLOCK, 0);  
  
	if (-1 == fd)  
	{  
		fprintf(stderr, "Cannot open '%s': %d, %s\n",  
		dev_name, errno, strerror(errno));  
		exit(EXIT_FAILURE);  
	}  
}  

//  argv1  dev_name        /dev/videoX
//  argv2  resolution      320x240
//  argv3  filename        XXX.jpg           
int main(int argc, char **argv)  
{  
	dev_name = argv[1];
	resolution = argv[2];
	filename = argv[3];
	
	sscanf(resolution, "%dx%d", &width, &height);

	open_device();
	init_device();
    start_capture();
	uninit_device();
	close_device();
	exit(EXIT_SUCCESS);  
  
	return 0;  
} 
