//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dvdsample.rc
//
#define IDS_APP_TITLE                   1
#define DVDSample                       101
#define IDM_MENU1                       101
#define ID_SPINCONTROL                  101
#define IDI_APPICON                     103
#define IDR_TOOLBAR1                    117
#define IDD_PARENTLEVELS                120
#define IDD_ABOUT                       122
#define IDD_SPDLG                       123
#define IDD_AUDIODLG                    124
#define IDD_ANGLEDLG                    125
#define IDD_CHAPTERDLG                  126
#define IDD_TITLEDLG                    127
#define IDD_TIMEDLG                     128
#define IDD_KARAOKEDLG                  129
#define IDC_LEVEL_LIST                  1002
#define IDC_SPLANG                      1003
#define IDC_SHOWSP                      1004
#define IDC_AUDIOLANG                   1005
#define IDC_ANGLE                       1006
#define IDC_PLAYCHAPTER                 1007
#define IDC_PLAYTITLE                   1010
#define IDC_HOURS                       1011
#define IDC_MINUTES                     1012
#define IDC_SECONDS                     1013
#define IDC_CHANNEL2                    1016
#define IDC_CHANNEL3                    1017
#define IDC_CHANNEL4                    1018
#define ID_HELP_ABOUTDVDSAMPLE          40001
#define ID_FILE_EXIT                    40002
#define ID_PLAYBACK_PLAY                40003
#define ID_PLAYBACK_PAUSE               40004
#define ID_PLAYBACK_STOP                40005
#define ID_PLAYBACK_FASTFORWARD         40006
#define ID_PLAYBACK_REWIND              40007
#define ID_PLAYBACK_NEXTCHAPTER         40008
#define ID_PLAYBACK_PREVIOUSCHAPTER     40009
#define ID_PLAYBACK_MENUROOT            40010
#define ID_PLAYBACK_TITLEMENU           40011
#define ID_OPTIONS_SUBPICTURE           40012
#define ID_OPTIONS_AUDIOLANGUAGE        40013
#define ID_OPTIONS_PARENTALLEVEL        40014
#define ID_OPTIONS_CLOSEDCAPTION        40015
#define ID_OPTIONS_FULLSCREEN           40016
#define ID_OPTIONS_ANGLE                40017
#define ID_FILE_SELECTDISC              40018
#define ID_OPTIONS_SAVEBOOKMARK         40022
#define ID_OPTIONS_RESTOREBOOKMARK      40023
#define ID_PLAYBACK_GOTO_CHAPTER        40024
#define ID_PLAYBACK_GOTO_TIME           40025
#define ID_PLAYBACK_GOTO_TITLE          40026
#define ID_BUTTON40027                  40027
#define ID_PLAYBACK_STEPFORWARD         40029
#define ID_OPTIONS_GETDISCTEXT          40030
#define ID_OPTIONS_GETAUDIOATTRIBUTES   40031
#define ID_OPTIONS_GETVIDEOATTRIBUTES   40032
#define ID_OPTIONS_GETSUBPICTUREATTRIBUTES 40033
#define ID_OPTIONS_SETKARAOKEMIXING     40035
#define ID_OPTIONS_USEVMR9              40036

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40037
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
