//-----------------------------------------------------------------------------
// File: Resource.h
//
// Desc: Header file for DirectShow Background music player
//       
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Resource constants
//-----------------------------------------------------------------------------
#define IDI_BGMUSIC    10000

#define IDD_ABOUTBOX   100
#define IDM_ABOUTBOX   0x0010
