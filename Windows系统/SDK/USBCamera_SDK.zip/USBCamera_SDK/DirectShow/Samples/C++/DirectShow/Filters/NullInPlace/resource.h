//
// Microsoft Visual C++ generated include file.
// Used by nullprop.rc
//
#define IDD_DIALOG1                     101
#define IDC_MEDIALIST                   1001

#define IDS_PREFORMAT                   301
#define IDS_PREMAJOR                    302
#define IDS_PRESUB                      303
#define IDS_NOTYPE                      304
#define IDS_ANYTYPE                     305
#define IDS_TITLE                       306

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
