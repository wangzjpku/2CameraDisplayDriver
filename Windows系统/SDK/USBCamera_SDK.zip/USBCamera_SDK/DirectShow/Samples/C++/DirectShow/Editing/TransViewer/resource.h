//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TransViewer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_MAIN                        101
#define IDD_MAIN_WIDE                   102
#define IDD_PROPERTY                    103
#define IDD_EDITPROP                    104
#define IDI_ICON                        106
#define IDD_ABOUTBOX                    107
#define IDD_PICK_COLOR                  108
#define IDD_SMPTE                       109
#define IDD_COMPOSITOR                  110
#define IDD_KEY                         111
#define IDC_TRANS                       1000
#define IDC_PICK_CLIP1                  1001
#define IDC_PICK_CLIP2                  1002
#define IDC_CLIP1                       1003
#define IDC_CLIP2                       1004
#define IDC_PREVIEW                     1005
#define IDC_ERRORLOG                    1006
#define IDC_CLIP1_CAPTION               1007
#define IDC_CLIP2_CAPTION               1008
#define IDC_VIDWIN                      1009
#define IDC_PICK_COLOR1                 1010
#define IDC_PICK_COLOR2                 1011
#define IDC_PROPLIST                    1012
#define IDM_PROPERTIES                  1012
#define IDC_ADDNEW                      1013
#define IDC_EDIT                        1014
#define IDC_REMOVE                      1015
#define IDC_PROPNAME                    1016
#define IDC_PROPVAL                     1017
#define IDC_CHECK_CYCLE                 1018
#define IDC_CHECK_LOOP                  1019
#define IDC_STOP                        1020
#define IDC_STOP2                       1021
#define IDC_PAUSE                       1021
#define IDC_RED100                      1021
#define IDC_REDZERO                     1022
#define IDC_GREEN100                    1023
#define IDC_GREENZERO                   1024
#define IDC_BLUE100                     1025
#define IDC_BLUEZERO                    1026
#define IDC_COLOR_RECT                  1028
#define IDC_MASKNUM                     1029
#define IDC_SMPTE_SOFTNESS              1030
#define IDC_SMPTE_WIDTH                 1031
#define IDC_SMPTE_COLOR                 1034
#define IDC_SMPTE_PICK_COLOR            1035
#define IDC_SMPTE_OFFSETX               1036
#define IDC_SMPTE_REPLICATEX            1037
#define IDC_SMPTE_SCALEX                1038
#define IDC_SMPTE_OFFSETY               1039
#define IDC_SMPTE_REPLICATEY            1040
#define IDC_SMPTE_SCALEY                1041
#define IDC_KEY_COLOR                   1042
#define IDC_KEY_TYPE                    1043
#define IDC_KEY_HUE                     1044
#define IDC_KEY_INVERT                  1045
#define IDC_KEY_LUMA                    1046
#define IDC_KEY_PICK_COLOR              1047
#define IDC_KEY_SIMILARITY              1048
#define IDC_KEY_SIMILAR                 1049
#define IDC_COMP_CANVAS                 1050
#define IDM_PREVIEW                     1051
#define IDM_PROPS                       1052
#define IDM_PROPERTY                    1053
#define IDC_SMPTE_MASKNUM               1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
