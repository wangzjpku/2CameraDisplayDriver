//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dmodemo.rc
//
#define IDR_DEMOICON                    128
#define IDD_MAIN                        130
#define IDC_PLAY                        1000
#define IDC_STOP                        1001
#define IDC_SOUNDFILE                   1011
#define IDC_FILENAME                    1015
#define IDC_DMOCOMBO                    1019
#define IDC_SELECTDMO                   1020


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
