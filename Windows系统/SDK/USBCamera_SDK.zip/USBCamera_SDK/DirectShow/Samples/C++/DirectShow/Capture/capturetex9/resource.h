//-----------------------------------------------------------------------------
// File: Resource.h
//
// Desc: DirectShow sample code - resource constants
//       
// Copyright (c) Microsoft Corporation.  All rights reserved.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Resource constants
//-----------------------------------------------------------------------------
#define IDI_TEXTURES    10000
#define IDD_ABOUTBOX    10001
#define ID_HELP_ABOUT   10002


