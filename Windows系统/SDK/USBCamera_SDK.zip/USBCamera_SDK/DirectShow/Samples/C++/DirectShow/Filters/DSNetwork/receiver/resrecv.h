#define VER_DEBUG                       0
#define IDS_IPMULTICAST_RECV_CONFIG     1
#define IDD_IPMULTICAST_RECV_CONFIG     101
#define IDC_NIC                         1002
#define IDC_PORT                        1003
#define IDC_IP                          1004
#define IDC_SAVE                        1005
#define IDC_TTL                         1006
#define VERSION_RES_LANGUAGE            0x409
#ifndef VERSION_RES_CHARSET
#define VERSION_RES_CHARSET             1252
#endif
#define IDC_STATIC                      -1
#define IDS_IPMULTICAST_SEND_CONFIG     2
#define IDD_IPMULTICAST_SEND_CONFIG     102

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
