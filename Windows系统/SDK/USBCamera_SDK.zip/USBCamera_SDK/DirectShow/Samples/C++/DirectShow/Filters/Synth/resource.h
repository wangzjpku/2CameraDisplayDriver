//
// Microsoft Visual C++ generated include file.
// Used by synth.rc
//

#define IDD_BALLPROP                    101
#define IDD_SYNTHPROP1                  101
#define IDC_FREQUENCYTEXT               1002
#define IDC_FREQUENCY                   1003
#define IDC_AMPLITUDETEXT               1003
#define IDC_FREQTRACKBAR                1004
#define IDC_FREQUENCYGROUP              1005
#define IDC_WAVEFORMGROUP               1006
#define IDC_WAVESINE                    1007
#define IDC_WAVESQUARE                  1008
#define IDC_WAVESAWTOOTH                1009
#define IDC_WAVESWEEP                   1010
#define IDC_AMPLITUDETRACKBAR           1011
#define IDC_CHANNELS1                   1012
#define IDC_CHANNELS2                   1013
#define IDC_BITSPERSAMPLEGROUP          1014
#define IDC_BITSPERSAMPLE8              1015
#define IDC_BITSPERSAMPLE16             1016
#define IDC_SAMPLINGFREQUENCYGROUP      1017
#define IDC_SAMPLINGFREQ11              1018
#define IDC_SAMPLINGFREQ22              1019
#define IDC_SAMPLINGFREQ44              1020
#define IDC_AMPLITUDEGROUP              1021
#define IDC_SWEEP                       1023
#define IDS_SYNTHPROPNAME               1024
#define IDC_OUTPUTFORMAT                1025
#define IDC_OF_PCM                      1026
#define IDC_OF_MSADPCM                  1027

#define IDS_STATIC                      -1
#define IDC_CHANNELSGROUP               -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
