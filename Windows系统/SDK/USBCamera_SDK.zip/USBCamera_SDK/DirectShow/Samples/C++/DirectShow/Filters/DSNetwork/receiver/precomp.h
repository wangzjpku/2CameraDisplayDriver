
/*++

    Copyright (c)  Microsoft Corporation.  All Rights Reserved.

    Module Name:

        precomp.h

    Abstract:

        Globals to the receiver.

    Notes:

--*/


#include "projpch.h"
#include <commctrl.h>

#define NET_RECV(pf)            (reinterpret_cast <CNetworkReceiverFilter *> (pf))