// Microsoft Visual C++ generated include file.
// Used by scope.rc
//
#define IDD_SCOPEDIALOG                 101
#define IDI_ICON1                       103
#define IDC_L_GAIN                      1001
#define IDC_L_GAIN_TEXT                 1002
#define IDC_L_OFFSET                    1003
#define IDC_L_TITLE                     1004
#define IDC_TIMEBASE_TEXT               1004
#define IDC_L_AUTO                      1005
#define IDC_R_GAIN                      1006
#define IDC_R_GAIN_TEXT                 1007
#define IDC_R_OFFSET                    1008
#define IDC_R_TITLE                     1009
#define IDC_L_OFFSET_TEXT               1009
#define IDC_R_AUTO                      1010
#define IDC_TS_LAST                     1011
#define IDC_TB_START                    1012
#define IDC_TB_SCROLL                   1012
#define IDC_FREEZE                      1013
#define IDC_TIMEBASE                    1014
#define IDC_R_OFFSET_TEXT               1015
#define IDC_TS_START                    1016
#define IDC_TS_DELTA                    1017
#define IDC_SCOPEWINDOW                 1019
#define IDC_USER1                       1021
#define IDC_TRIGGER                     1022
#define IDC_FORMAT                      1023
#define IDC_BUFSIZE                     1024
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
